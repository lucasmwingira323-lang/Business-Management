# BUSINESS MANAGEMENT — GitHub + Supabase

This bundle contains:
- `index.html`: mobile-friendly GitHub Pages frontend.
- `supabase/migrations/202610250001_business_management.sql`: app tables and RLS policies.
- `supabase/functions/create-employee/index.ts`: server-side employee account creation.

## Important
Never put the Supabase `service_role` key in `index.html` or any public GitHub file. The Edge Function uses Supabase server environment secrets.

## Setup overview
1. Back up your current `index.html` in GitHub before replacing it.
2. Run the SQL migration in Supabase SQL Editor for the existing BUSINESS MANAGEMENT project.
3. Deploy the Edge Function named `create-employee` from the Supabase CLI or a connected deployment workflow.
4. Make sure the existing `user_profiles` table has `user_id`, `full_name`, `role`, `active`, `phone`, and `created_at`. Do not run the app if its schema differs; adjust the function to match the actual columns first.
5. Confirm the owner profile has `role = 'owner'` and `active = true`.
6. Replace the GitHub repository root `index.html` with this bundle's `index.html`, commit, and wait for GitHub Pages to redeploy.

## Edge Function secrets
Set these as Supabase Edge Function secrets:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`
- `SUPABASE_SERVICE_ROLE_KEY`

Supabase usually provides the first two to the runtime; set the service-role key only as a server-side secret. Never share it or commit it.

## Login
- Owner uses the existing real email + password.
- Employee uses username + password. The function creates employee auth emails like `username@bm.invalid`, confirmed by the Admin; no password-reset email is available for these synthetic usernames. Admin must use a secure process to reset an employee password if needed.

## Data and permissions
- `bm_records` stores app records and has RLS enabled.
- Owners can see all records and manage records.
- Employees can see only records they created, and can insert records for their assigned business.
- `bm_staff_businesses` stores the employee's username and assigned business.
- Existing tables are not dropped. The migration does not automatically copy old `transactions` rows into `bm_records`.

## Before going live
Test using a separate employee account. Verify that employee A cannot read employee B's rows, and that an employee cannot call the `create-employee` function. Review your existing `user_profiles` RLS policies, especially owner access to employee profiles.
