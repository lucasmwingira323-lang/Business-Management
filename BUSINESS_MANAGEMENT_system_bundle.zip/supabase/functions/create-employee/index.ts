import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Njia hii inaruhusu POST pekee." }, 405);

  const url = Deno.env.get("SUPABASE_URL")!;
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const authHeader = req.headers.get("Authorization");
  if (!authHeader) return json({ error: "Ingia kama Admin kwanza." }, 401);

  const callerClient = createClient(url, anonKey, {
    global: { headers: { Authorization: authHeader } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data: userData, error: userError } = await callerClient.auth.getUser();
  if (userError || !userData.user) return json({ error: "Akaunti haijathibitishwa." }, 401);

  const adminClient = createClient(url, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { data: profile, error: profileError } = await adminClient
    .from("user_profiles")
    .select("role,active")
    .eq("user_id", userData.user.id)
    .maybeSingle();

  if (profileError || !profile || String(profile.role).toLowerCase() !== "owner" || profile.active === false) {
    return json({ error: "Ni Admin/Mmiliki pekee anayeruhusiwa kufungua akaunti." }, 403);
  }

  let body: any;
  try { body = await req.json(); } catch { return json({ error: "Taarifa hazijasomeka." }, 400); }

  const fullName = String(body.full_name || "").trim();
  const username = String(body.username || "").trim().toLowerCase();
  const password = String(body.password || "");
  const businessName = String(body.business_name || "");
  const phone = String(body.phone || "").trim();

  const allowedBusinesses = ["Usafirishaji wa Mizigo", "Mashine ya Kusaga", "Biashara ya Trekta"];
  if (fullName.length < 2 || fullName.length > 100) return json({ error: "Ingiza jina kamili la mfanyakazi." }, 400);
  if (!/^[a-z0-9._-]{3,30}$/.test(username)) return json({ error: "Jina la mtumiaji liwe herufi, namba, nukta, _ au -; herufi 3 hadi 30." }, 400);
  if (password.length < 8 || password.length > 128) return json({ error: "Nenosiri liwe na angalau herufi 8." }, 400);
  if (!allowedBusinesses.includes(businessName)) return json({ error: "Chagua biashara iliyopo." }, 400);

  const { data: existing } = await adminClient
    .from("bm_staff_businesses").select("username").eq("username", username).maybeSingle();
  if (existing) return json({ error: "Jina hili la mtumiaji tayari linatumika." }, 409);

  // Synthetic login email lets staff use a username. Staff accounts are confirmed by Admin.
  const authEmail = `${username}@bm.invalid`;
  const { data: created, error: createError } = await adminClient.auth.admin.createUser({
    email: authEmail,
    password,
    email_confirm: true,
    user_metadata: { full_name: fullName, account_type: "employee" },
  });
  if (createError || !created.user) return json({ error: createError?.message || "Imeshindikana kuunda akaunti." }, 400);

  const userId = created.user.id;
  const { error: profileInsertError } = await adminClient.from("user_profiles").insert({
    user_id: userId,
    full_name: fullName,
    role: "employee",
    active: true,
    phone: phone || null,
  });

  if (profileInsertError) {
    await adminClient.auth.admin.deleteUser(userId);
    return json({ error: "Akaunti haikuweza kuunganishwa na user_profiles: " + profileInsertError.message }, 500);
  }

  const { error: assignmentError } = await adminClient.from("bm_staff_businesses").insert({
    user_id: userId,
    username,
    business_name: businessName,
  });

  if (assignmentError) {
    await adminClient.from("user_profiles").delete().eq("user_id", userId);
    await adminClient.auth.admin.deleteUser(userId);
    return json({ error: "Imeshindikana kuunganisha mfanyakazi na biashara: " + assignmentError.message }, 500);
  }

  return json({ ok: true, username, business_name: businessName });
});
